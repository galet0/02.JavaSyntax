import java.util.Scanner;

/**
 * Created by galeto on 17.03.16.
 */
public class _01_RectangleArea {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        double a = scn.nextDouble();
        double b = scn.nextDouble();
        double area = a * b;
        System.out.println(area);
    }
}
